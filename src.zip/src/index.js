import React from "react";

import  ReactDOM from "react-dom/client";

import NavBarForCurdRoute from "./project3/NavBarForCurdRoute";

import Lay from "./project3/Lay";

import CrudRoute from "./project3/CrudRoute";

// import BarCodeApp from "./project 1/BarCodeApp";

// import NavBar from "./project 2/NavBar";

// import LayOut from "./project 2/LayOut";
// import Routing from "./project 2/Routing";

// ReactDOM.createRoot(document.getElementById("root")).render(<BarCodeApp/>)

ReactDOM.createRoot(document.getElementById("root")).render(<Routing/>)

//ReactDOM.createRoot(document.getElementById("root")).render(<CrudRoute/>)